package com.careerguidance.ai;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.careerguidance.ai.services.FirebaseManager;

public class ForgotPasswordActivity extends AppCompatActivity {

    private EditText etEmail;
    private Button btnSendReset;
    private TextView tvStatus;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        etEmail = findViewById(R.id.etResetEmail);
        btnSendReset = findViewById(R.id.btnSendReset);
        tvStatus = findViewById(R.id.tvResetStatus);
        progressBar = findViewById(R.id.resetProgressBar);

        btnSendReset.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            if (TextUtils.isEmpty(email) || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                tvStatus.setText("Enter a valid email address.");
                tvStatus.setVisibility(View.VISIBLE);
                return;
            }

            progressBar.setVisibility(View.VISIBLE);
            btnSendReset.setEnabled(false);

            FirebaseManager.getInstance().resetPassword(email, task -> {
                progressBar.setVisibility(View.GONE);
                btnSendReset.setEnabled(true);

                if (task.isSuccessful()) {
                    Toast.makeText(this, "Password reset email sent!", Toast.LENGTH_LONG).show();
                    finish();
                } else {
                    String msg = task.getException() != null ? task.getException().getMessage() : "Failed to send reset email";
                    tvStatus.setText(msg);
                    tvStatus.setVisibility(View.VISIBLE);
                }
            });
        });
    }
}