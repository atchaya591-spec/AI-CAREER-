package com.careerguidance.ai.services;

import androidx.annotation.NonNull;

import com.careerguidance.ai.models.AssessmentResult;
import com.careerguidance.ai.models.UserProfile;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.util.HashMap;
import java.util.Map;

public class FirebaseManager {
    private static FirebaseManager instance;
    private final FirebaseAuth auth;
    private final FirebaseFirestore db;

    private FirebaseManager() {
        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
    }

    public static synchronized FirebaseManager getInstance() {
        if (instance == null) {
            instance = new FirebaseManager();
        }
        return instance;
    }

    public FirebaseUser getCurrentUser() {
        return auth.getCurrentUser();
    }

    public boolean isUserLoggedIn() {
        return auth.getCurrentUser() != null;
    }

    public void registerUser(String email, String password, OnCompleteListener<AuthResult> listener) {
        auth.createUserWithEmailAndPassword(email.trim(), password)
            .addOnCompleteListener(listener);
    }

    public void loginUser(String email, String password, OnCompleteListener<AuthResult> listener) {
        auth.signInWithEmailAndPassword(email.trim(), password)
            .addOnCompleteListener(listener);
    }

    public void resetPassword(String email, OnCompleteListener<Void> listener) {
        auth.sendPasswordResetEmail(email.trim())
            .addOnCompleteListener(listener);
    }

    public void logout() {
        auth.signOut();
    }

    // Save/Update student profile in Cloud Firestore
    public void saveUserProfile(UserProfile profile, OnCompleteListener<Void> listener) {
        if (getCurrentUser() == null) return;
        String uid = getCurrentUser().getUid();
        profile.setUid(uid);
        db.collection("students").document(uid)
            .set(profile, SetOptions.merge())
            .addOnCompleteListener(listener);
    }

    // Fetch student profile from Cloud Firestore
    public void fetchUserProfile(OnCompleteListener<DocumentSnapshot> listener) {
        if (getCurrentUser() == null) return;
        String uid = getCurrentUser().getUid();
        db.collection("students").document(uid)
            .get()
            .addOnCompleteListener(listener);
    }

    // Save assessment results
    public void saveAssessmentResult(AssessmentResult result, OnCompleteListener<Void> listener) {
        if (getCurrentUser() == null) return;
        String uid = getCurrentUser().getUid();
        result.setUserId(uid);
        result.setTimestamp(System.currentTimeMillis());

        // Update both the assessment document and the student flag
        db.collection("assessments").document(uid)
            .set(result, SetOptions.merge())
            .addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    Map<String, Object> update = new HashMap<>();
                    update.put("assessmentCompleted", true);
                    db.collection("students").document(uid).update(update);
                }
                if (listener != null) {
                    listener.onComplete(task);
                }
            });
    }

    // Save task progress / roadmap item
    public void saveRoadmapTaskDone(String taskId, boolean isDone, OnCompleteListener<Void> listener) {
        if (getCurrentUser() == null) return;
        String uid = getCurrentUser().getUid();
        Map<String, Object> data = new HashMap<>();
        data.put("done." + taskId, isDone);
        db.collection("progress").document(uid)
            .set(data, SetOptions.merge())
            .addOnCompleteListener(listener);
    }
}