package com.careerguidance.ai.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.careerguidance.ai.R;
import com.careerguidance.ai.models.CareerScoreResult;

import java.util.List;

public class CareerAdapter extends RecyclerView.Adapter<CareerAdapter.CareerViewHolder> {

    public interface OnCareerClickListener {
        void onExplore(CareerScoreResult result);
        void onExplain(CareerScoreResult result);
    }

    private final List<CareerScoreResult> items;
    private final OnCareerClickListener listener;

    public CareerAdapter(List<CareerScoreResult> items, OnCareerClickListener listener) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public CareerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_career_card, parent, false);
        return new CareerViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull CareerViewHolder holder, int position) {
        CareerScoreResult res = items.get(position);
        holder.tvIcon.setText(res.getCareer().getIcon());
        holder.tvTitle.setText(res.getCareer().getTitle());
        holder.tvScore.setText(res.getTotalScore() + "%");
        holder.tvWhy.setText(res.getExplainableSummary());

        holder.btnExplore.setOnClickListener(v -> listener.onExplore(res));
        holder.btnExplain.setOnClickListener(v -> listener.onExplain(res));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class CareerViewHolder extends RecyclerView.ViewHolder {
        TextView tvIcon, tvTitle, tvScore, tvWhy;
        Button btnExplore, btnExplain;

        CareerViewHolder(View itemView) {
            super(itemView);
            tvIcon = itemView.findViewById(R.id.tvItemCareerIcon);
            tvTitle = itemView.findViewById(R.id.tvItemCareerTitle);
            tvScore = itemView.findViewById(R.id.tvItemCareerScore);
            tvWhy = itemView.findViewById(R.id.tvItemCareerWhy);
            btnExplore = itemView.findViewById(R.id.btnItemCareerExplore);
            btnExplain = itemView.findViewById(R.id.btnItemCareerExplain);
        }
    }
}