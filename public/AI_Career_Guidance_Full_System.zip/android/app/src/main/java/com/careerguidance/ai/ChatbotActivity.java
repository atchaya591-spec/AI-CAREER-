package com.careerguidance.ai;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.careerguidance.ai.adapters.ChatAdapter;
import com.careerguidance.ai.models.ChatMessage;
import com.careerguidance.ai.models.UserProfile;
import com.careerguidance.ai.services.FirebaseManager;
import com.careerguidance.ai.services.GeminiAiService;
import com.google.android.material.chip.Chip;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ChatbotActivity extends AppCompatActivity {

    private RecyclerView rvChat;
    private EditText etInput;
    private ImageButton btnSend;
    private ProgressBar pbThinking;
    private ChatAdapter chatAdapter;
    private List<ChatMessage> messageList;

    private GeminiAiService geminiService;
    private UserProfile userProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatbot);

        rvChat = findViewById(R.id.rvChatMessages);
        etInput = findViewById(R.id.etChatMessage);
        btnSend = findViewById(R.id.btnChatSend);
        pbThinking = findViewById(R.id.pbChatThinking);

        messageList = new ArrayList<>();
        chatAdapter = new ChatAdapter(messageList);
        rvChat.setLayoutManager(new LinearLayoutManager(this));
        rvChat.setAdapter(chatAdapter);

        geminiService = new GeminiAiService();

        // Initial welcoming message
        messageList.add(new ChatMessage("1", "Hello! I am your AI Career Copilot. Ask me about programming roadmaps, interview prep, skill gaps, or resume strategies.", false, getNowTime(), "gemini"));
        chatAdapter.notifyDataSetChanged();

        btnSend.setOnClickListener(v -> sendMessage());

        setupQuickPromptChips();
        loadUserProfile();
    }

    private void loadUserProfile() {
        FirebaseManager.getInstance().fetchUserProfile(task -> {
            if (task.isSuccessful() && task.getResult() != null && task.getResult().exists()) {
                userProfile = task.getResult().toObject(UserProfile.class);
            }
        });
    }

    private void setupQuickPromptChips() {
        findViewById(R.id.chipPrompt1).setOnClickListener(v -> {
            etInput.setText("Explain my top career match and required skills.");
            sendMessage();
        });
        findViewById(R.id.chipPrompt2).setOnClickListener(v -> {
            etInput.setText("What beginner project should I build first?");
            sendMessage();
        });
        findViewById(R.id.chipPrompt3).setOnClickListener(v -> {
            etInput.setText("Give me a 4-week study roadmap for DSA and System Design.");
            sendMessage();
        });
    }

    private void sendMessage() {
        String text = etInput.getText().toString().trim();
        if (TextUtils.isEmpty(text)) return;

        etInput.setText("");
        messageList.add(new ChatMessage(String.valueOf(System.currentTimeMillis()), text, true, getNowTime(), "user"));
        chatAdapter.notifyItemInserted(messageList.size() - 1);
        rvChat.scrollToPosition(messageList.size() - 1);

        pbThinking.setVisibility(View.VISIBLE);

        geminiService.sendMessage(text, messageList, userProfile, new GeminiAiService.AiChatCallback() {
            @Override
            public void onSuccess(String reply, String source) {
                pbThinking.setVisibility(View.GONE);
                messageList.add(new ChatMessage(String.valueOf(System.currentTimeMillis()), reply, false, getNowTime(), source));
                chatAdapter.notifyItemInserted(messageList.size() - 1);
                rvChat.scrollToPosition(messageList.size() - 1);
            }

            @Override
            public void onError(String errorMessage) {
                pbThinking.setVisibility(View.GONE);
                Toast.makeText(ChatbotActivity.this, "Offline guidance: " + errorMessage, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private String getNowTime() {
        return new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(new Date());
    }
}