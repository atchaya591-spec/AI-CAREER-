package com.careerguidance.ai.services;

import com.careerguidance.ai.models.AssessmentResult;
import com.careerguidance.ai.models.CareerModel;
import com.careerguidance.ai.models.CareerScoreResult;
import com.careerguidance.ai.models.UserProfile;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CareerScoringEngine {

    // Default built-in careers
    public static List<CareerModel> getStandardCareers() {
        List<CareerModel> list = new ArrayList<>();

        // Software Engineer
        Map<String, Double> sweDims = new HashMap<>();
        sweDims.put("B", 1.0); sweDims.put("A", 0.6); sweDims.put("C", 0.3); sweDims.put("P", 0.2); sweDims.put("L", 0.2);
        Map<String, Double> sweStyle = new HashMap<>();
        sweStyle.put("S", 0.8); sweStyle.put("T", 0.6); sweStyle.put("L", 0.2); sweStyle.put("X", 0.5);
        list.add(new CareerModel("swe", "Software Engineer", "💻",
                "Architect, code, test, and scale mission-critical software systems and applications.",
                sweDims, sweStyle, 0.65,
                Arrays.asList("Java", "DSA (Data Structures)", "SQL & Databases", "Git & GitHub", "Unit Testing", "Communication"),
                Arrays.asList("software", "developer", "engineer", "swe", "backend"),
                "+25% (Much faster than average)", "$110,000 - $165,000"));

        // AI / ML Engineer
        Map<String, Double> mlDims = new HashMap<>();
        mlDims.put("B", 0.7); mlDims.put("A", 1.0); mlDims.put("C", 0.3); mlDims.put("P", 0.1); mlDims.put("L", 0.1);
        Map<String, Double> mlStyle = new HashMap<>();
        mlStyle.put("S", 0.8); mlStyle.put("T", 0.4); mlStyle.put("L", 0.1); mlStyle.put("X", 0.8);
        list.add(new CareerModel("ml", "AI / ML Engineer", "🤖",
                "Design, train, optimize, and deploy neural networks and intelligent data pipelines.",
                mlDims, mlStyle, 0.75,
                Arrays.asList("Python", "Statistics", "Machine Learning", "DSA (Data Structures)", "SQL & Databases", "Git & GitHub"),
                Arrays.asList("ai", "ml", "machine learning", "data scientist", "deep learning"),
                "+36% (Extremely high demand)", "$130,000 - $190,000"));

        // Data Analyst
        Map<String, Double> daDims = new HashMap<>();
        daDims.put("B", 0.3); daDims.put("A", 1.0); daDims.put("C", 0.3); daDims.put("P", 0.4); daDims.put("L", 0.3);
        Map<String, Double> daStyle = new HashMap<>();
        daStyle.put("S", 0.6); daStyle.put("T", 0.6); daStyle.put("L", 0.3); daStyle.put("X", 0.4);
        list.add(new CareerModel("da", "Data Analyst", "📊",
                "Transform complex data streams into actionable intelligence to steer business and product strategy.",
                daDims, daStyle, 0.60,
                Arrays.asList("SQL & Databases", "Python", "Statistics", "Data Visualization", "Communication"),
                Arrays.asList("data", "analyst", "analytics", "bi"),
                "+23% (Rapid growth)", "$85,000 - $125,000"));

        // UI/UX Designer
        Map<String, Double> uxDims = new HashMap<>();
        uxDims.put("B", 0.3); uxDims.put("A", 0.4); uxDims.put("C", 1.0); uxDims.put("P", 0.6); uxDims.put("L", 0.2);
        Map<String, Double> uxStyle = new HashMap<>();
        uxStyle.put("S", 0.4); uxStyle.put("T", 0.7); uxStyle.put("L", 0.2); uxStyle.put("X", 0.9);
        list.add(new CareerModel("ux", "UI / UX Designer", "🎨",
                "Synthesize user behavior research into delightful, accessible, and high-impact digital experiences.",
                uxDims, uxStyle, 0.50,
                Arrays.asList("Figma", "UX Research", "HTML/CSS", "Communication", "Data Visualization"),
                Arrays.asList("design", "ux", "ui", "designer"),
                "+16% (Faster than average)", "$90,000 - $140,000"));

        // Cybersecurity Analyst
        Map<String, Double> secDims = new HashMap<>();
        secDims.put("B", 0.7); secDims.put("A", 0.9); secDims.put("C", 0.2); secDims.put("P", 0.2); secDims.put("L", 0.3);
        Map<String, Double> secStyle = new HashMap<>();
        secStyle.put("S", 0.8); secStyle.put("T", 0.5); secStyle.put("L", 0.3); secStyle.put("X", 0.5);
        list.add(new CareerModel("sec", "Cybersecurity Analyst", "🛡️",
                "Safeguard infrastructure, networks, and cloud assets by identifying and neutralizing threats.",
                secDims, secStyle, 0.70,
                Arrays.asList("Networking", "Security Basics", "Python", "Git & GitHub", "Communication"),
                Arrays.asList("security", "cyber", "infosec"),
                "+32% (Critical shortage)", "$105,000 - $155,000"));

        // Product Manager
        Map<String, Double> pmDims = new HashMap<>();
        pmDims.put("B", 0.4); pmDims.put("A", 0.7); pmDims.put("C", 0.5); pmDims.put("P", 0.8); pmDims.put("L", 1.0);
        Map<String, Double> pmStyle = new HashMap<>();
        pmStyle.put("S", 0.2); pmStyle.put("T", 0.8); pmStyle.put("L", 1.0); pmStyle.put("X", 0.5);
        list.add(new CareerModel("pm", "Product Manager", "🧭",
                "Define product vision, align cross-functional engineering teams, and deliver user value.",
                pmDims, pmStyle, 0.60,
                Arrays.asList("Product Thinking", "Communication", "Leadership & Agile", "SQL & Databases", "Data Visualization"),
                Arrays.asList("product", "manager", "pm"),
                "+18% (Strong demand)", "$115,000 - $175,000"));

        return list;
    }

    public static List<CareerScoreResult> rankCareers(UserProfile profile, AssessmentResult assessment) {
        List<CareerScoreResult> results = new ArrayList<>();
        List<CareerModel> careers = getStandardCareers();

        Map<String, Double> userInterestVec = computeInterestVector(assessment);
        Map<String, Double> userStyleVec = computeStyleVector(assessment);
        double userAptitudeRatio = assessment != null && assessment.getTotalAptitudeQuestions() > 0
                ? (double) assessment.getAptitudeScore() / assessment.getTotalAptitudeQuestions() : 0.6;

        List<String> studentSkills = profile != null && profile.getTechnicalSkills() != null
                ? profile.getTechnicalSkills() : Collections.emptyList();
        String studentGoal = profile != null && profile.getCareerGoal() != null
                ? profile.getCareerGoal().toLowerCase() : "";

        for (CareerModel c : careers) {
            double iFit = cosineSimilarity(userInterestVec, c.getDimensions());
            double aFit = Math.min(1.0, userAptitudeRatio / c.getAptitudeThreshold());
            double sFit = cosineSimilarity(userStyleVec, c.getStyles());

            List<String> matched = new ArrayList<>();
            List<String> missing = new ArrayList<>();
            for (String req : c.getRequiredSkills()) {
                if (studentSkills.contains(req)) {
                    matched.add(req);
                } else {
                    missing.add(req);
                }
            }
            double kFit = c.getRequiredSkills().isEmpty() ? 0.5 : (double) matched.size() / c.getRequiredSkills().size();

            double gFit = 0.5;
            if (!studentGoal.isEmpty() && !studentGoal.contains("not sure")) {
                if (studentGoal.equalsIgnoreCase(c.getTitle()) || c.getTags().stream().anyMatch(studentGoal::contains)) {
                    gFit = 1.0;
                } else {
                    gFit = 0.3;
                }
            }

            // Weighted multi-factor formula:
            // 30% Interest RIASEC, 20% Aptitude, 15% Work Style, 20% Verified Skills, 15% Goal Alignment
            int total = (int) Math.round((iFit * 0.30 + aFit * 0.20 + sFit * 0.15 + kFit * 0.20 + gFit * 0.15) * 100);
            total = Math.max(10, Math.min(99, total));

            String why = buildWhyExplanation((int)(iFit*100), (int)(aFit*100), matched, missing);

            results.add(new CareerScoreResult(c, total, (int)(iFit*100), (int)(aFit*100),
                    (int)(sFit*100), (int)(kFit*100), (int)(gFit*100), matched, missing, why));
        }

        // Sort descending by total match score
        Collections.sort(results, (a, b) -> Integer.compare(b.getTotalScore(), a.getTotalScore()));
        return results;
    }

    private static double cosineSimilarity(Map<String, Double> v1, Map<String, Double> v2) {
        if (v1 == null || v2 == null || v1.isEmpty() || v2.isEmpty()) return 0.5;
        double dot = 0.0, mag1 = 0.0, mag2 = 0.0;
        for (String k : v2.keySet()) {
            double a = v1.getOrDefault(k, 0.0);
            double b = v2.get(k);
            dot += a * b;
            mag1 += a * a;
            mag2 += b * b;
        }
        return (mag1 > 0 && mag2 > 0) ? dot / (Math.sqrt(mag1) * Math.sqrt(mag2)) : 0.5;
    }

    private static Map<String, Double> computeInterestVector(AssessmentResult a) {
        Map<String, Double> vec = new HashMap<>();
        vec.put("B", 1.0); vec.put("A", 1.0); vec.put("C", 1.0); vec.put("P", 1.0); vec.put("L", 1.0);
        if (a == null || a.getInterestAnswers() == null) return vec;
        // Map answer indices to dimensions B, A, C, P, L
        String[] dims = {"B", "A", "C", "P", "L"};
        for (int ans : a.getInterestAnswers()) {
            if (ans >= 0 && ans < dims.length) {
                String d = dims[ans];
                vec.put(d, vec.getOrDefault(d, 0.0) + 1.0);
            }
        }
        return vec;
    }

    private static Map<String, Double> computeStyleVector(AssessmentResult a) {
        Map<String, Double> vec = new HashMap<>();
        vec.put("S", 1.0); vec.put("T", 1.0); vec.put("L", 1.0); vec.put("X", 1.0);
        if (a == null || a.getPersonalityAnswers() == null) return vec;
        String[] styles = {"S", "T", "L", "X"};
        for (int ans : a.getPersonalityAnswers()) {
            if (ans >= 0 && ans < styles.length) {
                String s = styles[ans];
                vec.put(s, vec.getOrDefault(s, 0.0) + 1.0);
            }
        }
        return vec;
    }

    private static String buildWhyExplanation(int iFit, int aFit, List<String> have, List<String> missing) {
        StringBuilder sb = new StringBuilder();
        if (iFit >= 75) sb.append("Your natural interests align strongly with day-to-day role duties. ");
        if (aFit >= 85) sb.append("Your aptitude benchmark meets or exceeds entry requirements. ");
        if (!have.isEmpty()) sb.append("You already hold: ").append(String.join(", ", have)).append(". ");
        if (!missing.isEmpty()) sb.append("Key skill gaps to close: ").append(String.join(", ", missing)).append(".");
        return sb.toString().trim();
    }
}