package com.careerguidance.ai.models;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class CareerModel implements Serializable {
    private String id;
    private String title;
    private String icon;
    private String description;
    private Map<String, Double> dimensions; // B: Build, A: Analyse, C: Create, P: People, L: Lead
    private Map<String, Double> styles;     // S: Independent, T: Team, L: Leading, X: Experimenting
    private double aptitudeThreshold;
    private List<String> requiredSkills;
    private List<String> tags;
    private String growthOutlook;
    private String salaryRange;

    public CareerModel() {}

    public CareerModel(String id, String title, String icon, String description,
                       Map<String, Double> dimensions, Map<String, Double> styles,
                       double aptitudeThreshold, List<String> requiredSkills,
                       List<String> tags, String growthOutlook, String salaryRange) {
        this.id = id;
        this.title = title;
        this.icon = icon;
        this.description = description;
        this.dimensions = dimensions;
        this.styles = styles;
        this.aptitudeThreshold = aptitudeThreshold;
        this.requiredSkills = requiredSkills;
        this.tags = tags;
        this.growthOutlook = growthOutlook;
        this.salaryRange = salaryRange;
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getIcon() { return icon; }
    public String getDescription() { return description; }
    public Map<String, Double> getDimensions() { return dimensions; }
    public Map<String, Double> getStyles() { return styles; }
    public double getAptitudeThreshold() { return aptitudeThreshold; }
    public List<String> getRequiredSkills() { return requiredSkills; }
    public List<String> getTags() { return tags; }
    public String getGrowthOutlook() { return growthOutlook; }
    public String getSalaryRange() { return salaryRange; }
}