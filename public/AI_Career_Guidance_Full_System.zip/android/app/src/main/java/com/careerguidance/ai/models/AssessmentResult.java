package com.careerguidance.ai.models;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class AssessmentResult implements Serializable {
    private String userId;
    private List<Integer> interestAnswers;
    private List<Integer> aptitudeAnswers;
    private List<Integer> personalityAnswers;
    private String reflectionText;
    private String confidenceLevel;
    private List<String> preferredEnvironments;
    private int aptitudeScore;
    private int totalAptitudeQuestions;
    private long timestamp;

    public AssessmentResult() {}

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public List<Integer> getInterestAnswers() { return interestAnswers; }
    public void setInterestAnswers(List<Integer> interestAnswers) { this.interestAnswers = interestAnswers; }

    public List<Integer> getAptitudeAnswers() { return aptitudeAnswers; }
    public void setAptitudeAnswers(List<Integer> aptitudeAnswers) { this.aptitudeAnswers = aptitudeAnswers; }

    public List<Integer> getPersonalityAnswers() { return personalityAnswers; }
    public void setPersonalityAnswers(List<Integer> personalityAnswers) { this.personalityAnswers = personalityAnswers; }

    public String getReflectionText() { return reflectionText; }
    public void setReflectionText(String reflectionText) { this.reflectionText = reflectionText; }

    public String getConfidenceLevel() { return confidenceLevel; }
    public void setConfidenceLevel(String confidenceLevel) { this.confidenceLevel = confidenceLevel; }

    public List<String> getPreferredEnvironments() { return preferredEnvironments; }
    public void setPreferredEnvironments(List<String> preferredEnvironments) { this.preferredEnvironments = preferredEnvironments; }

    public int getAptitudeScore() { return aptitudeScore; }
    public void setAptitudeScore(int aptitudeScore) { this.aptitudeScore = aptitudeScore; }

    public int getTotalAptitudeQuestions() { return totalAptitudeQuestions; }
    public void setTotalAptitudeQuestions(int totalAptitudeQuestions) { this.totalAptitudeQuestions = totalAptitudeQuestions; }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
}