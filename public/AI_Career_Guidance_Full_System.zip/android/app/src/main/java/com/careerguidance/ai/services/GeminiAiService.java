package com.careerguidance.ai.services;

import android.os.Handler;
import android.os.Looper;

import com.careerguidance.ai.models.ChatMessage;
import com.careerguidance.ai.models.UserProfile;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class GeminiAiService {
    // Configurable backend URL. In production, points to Cloud Run / Firebase Functions backend proxy.
    // In local emulator testing, 10.0.2.2 accesses localhost on host machine.
    private static final String DEFAULT_BACKEND_URL = "https://ais-dev-fvn55wk47xf3j57tl3asvp-417744212480.asia-southeast1.run.app/api/ai/chat";
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    private final OkHttpClient httpClient;
    private final Gson gson;
    private final Handler mainHandler;

    public interface AiChatCallback {
        void onSuccess(String reply, String source);
        void onError(String errorMessage);
    }

    public GeminiAiService() {
        this.httpClient = new OkHttpClient();
        this.gson = new Gson();
        this.mainHandler = new Handler(Looper.getMainLooper());
    }

    public void sendMessage(String userMessage, List<ChatMessage> history, UserProfile profile, AiChatCallback callback) {
        JsonObject payload = new JsonObject();
        payload.addProperty("message", userMessage);

        JsonArray historyArray = new JsonArray();
        if (history != null) {
            for (ChatMessage m : history) {
                JsonObject msgObj = new JsonObject();
                msgObj.addProperty("role", m.isUser() ? "user" : "model");
                msgObj.addProperty("text", m.getMessage());
                historyArray.add(msgObj);
            }
        }
        payload.add("history", historyArray);

        JsonObject profileObj = new JsonObject();
        if (profile != null) {
            profileObj.addProperty("name", profile.getName());
            profileObj.addProperty("edu", profile.getDegree());
            profileObj.addProperty("year", profile.getYearOfStudy());
            profileObj.addProperty("targetCareer", profile.getTargetCareerId());
        }
        payload.add("userProfile", profileObj);

        RequestBody body = RequestBody.create(payload.toString(), JSON);
        Request request = new Request.Builder()
                .url(DEFAULT_BACKEND_URL)
                .post(body)
                .build();

        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                mainHandler.post(() -> callback.onError("Network error: " + e.getMessage()));
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    mainHandler.post(() -> callback.onError("Server returned code " + response.code()));
                    return;
                }
                String respBody = response.body().string();
                try {
                    JsonObject respJson = gson.fromJson(respBody, JsonObject.class);
                    String reply = respJson.has("reply") ? respJson.get("reply").getAsString() : "No reply";
                    String source = respJson.has("source") ? respJson.get("source").getAsString() : "gemini";
                    mainHandler.post(() -> callback.onSuccess(reply, source));
                } catch (Exception parseEx) {
                    mainHandler.post(() -> callback.onError("Failed to parse response"));
                }
            }
        });
    }
}