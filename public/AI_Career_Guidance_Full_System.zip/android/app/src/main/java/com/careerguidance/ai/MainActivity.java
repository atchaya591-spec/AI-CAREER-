package com.careerguidance.ai;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.careerguidance.ai.models.CareerScoreResult;
import com.careerguidance.ai.models.UserProfile;
import com.careerguidance.ai.services.CareerScoringEngine;
import com.careerguidance.ai.services.FirebaseManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextView tvGreeting, tvTopMatch, tvRoadmapPct, tvPriorityGaps;
    private View cardNextAction, cardAssess, cardCareers, cardGaps, cardProgress;
    private FloatingActionButton fabChatbot;
    private BottomNavigationView bottomNav;

    private UserProfile currentProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvGreeting = findViewById(R.id.tvHomeGreeting);
        tvTopMatch = findViewById(R.id.tvHomeTopMatch);
        tvRoadmapPct = findViewById(R.id.tvHomeRoadmapPct);
        tvPriorityGaps = findViewById(R.id.tvHomePriorityGaps);

        cardNextAction = findViewById(R.id.cardNextAction);
        cardAssess = findViewById(R.id.cardAssess);
        cardCareers = findViewById(R.id.cardCareers);
        cardGaps = findViewById(R.id.cardGaps);
        cardProgress = findViewById(R.id.cardProgress);
        fabChatbot = findViewById(R.id.fabChatbot);
        bottomNav = findViewById(R.id.bottomNavigation);

        setupClickListeners();
        setupBottomNav();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadDashboardData();
    }

    private void loadDashboardData() {
        FirebaseManager.getInstance().fetchUserProfile(task -> {
            if (task.isSuccessful() && task.getResult() != null && task.getResult().exists()) {
                currentProfile = task.getResult().toObject(UserProfile.class);
            }
            if (currentProfile == null) {
                currentProfile = new UserProfile("local", "Student", "student@example.com");
            }
            updateUI();
        });
    }

    private void updateUI() {
        String firstName = currentProfile.getName() != null ? currentProfile.getName().split(" ")[0] : "Student";
        tvGreeting.setText("Hello, " + firstName + " 👋");

        List<CareerScoreResult> ranked = CareerScoringEngine.rankCareers(currentProfile, null);
        if (!ranked.isEmpty()) {
            CareerScoreResult top = ranked.get(0);
            tvTopMatch.setText(top.getTotalScore() + "%");
            tvPriorityGaps.setText(String.valueOf(top.getMissingSkills().size()));
        } else {
            tvTopMatch.setText("–");
            tvPriorityGaps.setText("–");
        }
        tvRoadmapPct.setText("25%");
    }

    private void setupClickListeners() {
        cardAssess.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, AssessmentActivity.class)));

        cardCareers.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, CareerRecommendationsActivity.class)));

        cardGaps.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, SkillGapActivity.class)));

        cardProgress.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, ProgressActivity.class)));

        cardNextAction.setOnClickListener(v -> {
            if (currentProfile != null && !currentProfile.isAssessmentCompleted()) {
                startActivity(new Intent(MainActivity.this, AssessmentActivity.class));
            } else {
                startActivity(new Intent(MainActivity.this, CareerRecommendationsActivity.class));
            }
        });

        fabChatbot.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, ChatbotActivity.class)));
    }

    private void setupBottomNav() {
        bottomNav.setSelectedItemId(R.id.nav_home);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                return true;
            } else if (id == R.id.nav_assess) {
                startActivity(new Intent(this, AssessmentActivity.class));
                return true;
            } else if (id == R.id.nav_careers) {
                startActivity(new Intent(this, CareerRecommendationsActivity.class));
                return true;
            } else if (id == R.id.nav_roadmap) {
                startActivity(new Intent(this, RoadmapActivity.class));
                return true;
            } else if (id == R.id.nav_profile) {
                startActivity(new Intent(this, ProfileActivity.class));
                return true;
            }
            return false;
        });
    }
}