package com.careerguidance.ai;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.careerguidance.ai.models.UserProfile;
import com.careerguidance.ai.services.FirebaseManager;

public class RegisterActivity extends AppCompatActivity {

    private EditText etName, etEmail, etPassword;
    private Button btnRegister;
    private TextView tvGoLogin, tvError;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etName = findViewById(R.id.etRegName);
        etEmail = findViewById(R.id.etRegEmail);
        etPassword = findViewById(R.id.etRegPassword);
        btnRegister = findViewById(R.id.btnPerformRegister);
        tvGoLogin = findViewById(R.id.tvRegGoLogin);
        tvError = findViewById(R.id.tvRegError);
        progressBar = findViewById(R.id.regProgressBar);

        btnRegister.setOnClickListener(v -> attemptRegister());
        tvGoLogin.setOnClickListener(v -> finish());
    }

    private void attemptRegister() {
        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        tvError.setVisibility(View.GONE);

        if (TextUtils.isEmpty(name) || name.length() < 2) {
            tvError.setText("Please enter your full name.");
            tvError.setVisibility(View.VISIBLE);
            return;
        }

        if (TextUtils.isEmpty(email) || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            tvError.setText("Please enter a valid email address.");
            tvError.setVisibility(View.VISIBLE);
            return;
        }

        if (TextUtils.isEmpty(password) || password.length() < 6) {
            tvError.setText("Password must be at least 6 characters.");
            tvError.setVisibility(View.VISIBLE);
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        btnRegister.setEnabled(false);

        FirebaseManager fm = FirebaseManager.getInstance();
        fm.registerUser(email, password, task -> {
            if (task.isSuccessful()) {
                String uid = task.getResult().getUser().getUid();
                UserProfile profile = new UserProfile(uid, name, email);
                fm.saveUserProfile(profile, saveTask -> {
                    progressBar.setVisibility(View.GONE);
                    btnRegister.setEnabled(true);

                    Toast.makeText(RegisterActivity.this, "Account created successfully!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(RegisterActivity.this, ProfileActivity.class);
                    startActivity(intent);
                    finish();
                });
            } else {
                progressBar.setVisibility(View.GONE);
                btnRegister.setEnabled(true);
                String errorMsg = task.getException() != null ? task.getException().getMessage() : "Registration failed";
                tvError.setText(errorMsg);
                tvError.setVisibility(View.VISIBLE);
            }
        });
    }
}