package com.careerguidance.ai.models;

import java.io.Serializable;
import java.util.List;

public class CareerScoreResult implements Serializable {
    private CareerModel career;
    private int totalScore;
    private int interestFit;
    private int aptitudeFit;
    private int styleFit;
    private int skillCoverageFit;
    private int goalFit;
    private List<String> matchedSkills;
    private List<String> missingSkills;
    private String explainableSummary;

    public CareerScoreResult() {}

    public CareerScoreResult(CareerModel career, int totalScore, int interestFit, int aptitudeFit,
                             int styleFit, int skillCoverageFit, int goalFit,
                             List<String> matchedSkills, List<String> missingSkills,
                             String explainableSummary) {
        this.career = career;
        this.totalScore = totalScore;
        this.interestFit = interestFit;
        this.aptitudeFit = aptitudeFit;
        this.styleFit = styleFit;
        this.skillCoverageFit = skillCoverageFit;
        this.goalFit = goalFit;
        this.matchedSkills = matchedSkills;
        this.missingSkills = missingSkills;
        this.explainableSummary = explainableSummary;
    }

    public CareerModel getCareer() { return career; }
    public int getTotalScore() { return totalScore; }
    public int getInterestFit() { return interestFit; }
    public int getAptitudeFit() { return aptitudeFit; }
    public int getStyleFit() { return styleFit; }
    public int getSkillCoverageFit() { return skillCoverageFit; }
    public int getGoalFit() { return goalFit; }
    public List<String> getMatchedSkills() { return matchedSkills; }
    public List<String> getMissingSkills() { return missingSkills; }
    public String getExplainableSummary() { return explainableSummary; }
}