package com.careerguidance.ai.models;

public class ChatMessage {
    private String id;
    private String message;
    private boolean isUser;
    private String timestamp;
    private String source;

    public ChatMessage() {}

    public ChatMessage(String id, String message, boolean isUser, String timestamp, String source) {
        this.id = id;
        this.message = message;
        this.isUser = isUser;
        this.timestamp = timestamp;
        this.source = source;
    }

    public String getId() { return id; }
    public String getMessage() { return message; }
    public boolean isUser() { return isUser; }
    public String getTimestamp() { return timestamp; }
    public String getSource() { return source; }
}