package com.careerguidance.ai.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class UserProfile implements Serializable {
    private String uid;
    private String name;
    private String email;
    private String degree;
    private String department;
    private String yearOfStudy;
    private List<String> technicalSkills;
    private List<String> interests;
    private String careerGoal;
    private boolean assessmentCompleted;
    private String targetCareerId;

    public UserProfile() {
        // Default no-arg constructor required for Cloud Firestore deserialization
        this.technicalSkills = new ArrayList<>();
        this.interests = new ArrayList<>();
        this.assessmentCompleted = false;
    }

    public UserProfile(String uid, String name, String email) {
        this();
        this.uid = uid;
        this.name = name;
        this.email = email;
    }

    // Getters and Setters
    public String getUid() { return uid; }
    public void setUid(String uid) { this.uid = uid; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getDegree() { return degree; }
    public void setDegree(String degree) { this.degree = degree; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getYearOfStudy() { return yearOfStudy; }
    public void setYearOfStudy(String yearOfStudy) { this.yearOfStudy = yearOfStudy; }

    public List<String> getTechnicalSkills() { return technicalSkills; }
    public void setTechnicalSkills(List<String> technicalSkills) { this.technicalSkills = technicalSkills; }

    public List<String> getInterests() { return interests; }
    public void setInterests(List<String> interests) { this.interests = interests; }

    public String getCareerGoal() { return careerGoal; }
    public void setCareerGoal(String careerGoal) { this.careerGoal = careerGoal; }

    public boolean isAssessmentCompleted() { return assessmentCompleted; }
    public void setAssessmentCompleted(boolean assessmentCompleted) { this.assessmentCompleted = assessmentCompleted; }

    public String getTargetCareerId() { return targetCareerId; }
    public void setTargetCareerId(String targetCareerId) { this.targetCareerId = targetCareerId; }
}