# AI Enhanced Career Guidance System – Android Studio Project

## Prerequisites
1. **Android Studio Hedgehog / Iguana / Jellyfish** or newer (with JDK 17 or JDK 18).
2. **Android SDK API 34** installed via SDK Manager.
3. An active **Firebase Project** with Email/Password Authentication & Cloud Firestore enabled.

## Quick Setup Steps
1. Open Android Studio and select **File > Open**, then choose this project directory.
2. Ensure `google-services.json` is located in the `app/` folder (download from Firebase Console > Project Settings > Your Android App).
3. In Android Studio, click **Sync Project with Gradle Files**.
4. Run on an Android Emulator (API 31+) or physical device by clicking **Run 'app' (Shift+F10)**.

## Security Architecture
- Private API keys are never bundled directly in the client APK.
- The AI Career Chatbot talks to the secure proxy backend endpoint `/api/ai/chat` where Gemini 3.8 Flash handles queries.
- Cloud Firestore security rules strictly protect each student's personal assessment and profile data under their unique Firebase Auth UID.